<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>

        <script type="text/javascript">
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "<?php echo e($message); ?>"
            });
        </script>

    <?php endif; ?>



        <div class="search-form">
            <form action="<?php echo e(route('books.index')); ?>" method="GET" accept-charset="UTF-8" role="search">

                <input type="text" id="search" name="search" placeholder="Enter book name" value="<?php echo e(request('search')); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="add-button">
            <a href="<?php echo e(route('books.create')); ?>" class="button">Add New Book</a>
        </div>
        <br style="clear: both"><br>


        <!-- Example data for testing, replace with your actual data -->


            <?php if(count($books) > 0): ?>
            <table>
                <thead>
                <tr>
                    <th>Book Name</th>
                    <th>Cover</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Publication Year</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->book_name); ?></td>
                        <td><img src="<?php echo e(asset('images/'.$row->cover)); ?>" alt="Book Cover" width="50"></td>
                        <td><?php echo e($row->author); ?></td>
                        <td><?php echo e($row->category); ?></td>
                        <td><?php echo e(date('Y', strtotime($row->publication_year))); ?></td>
                        <td>
                            <a href="<?php echo e(route('books.edit', $row->id)); ?>" title="Edit"><i class="fas fa-edit"></i></a>
                            <form style="margin: 0px; padding: 0px; display: inline-block;" action="<?php echo e(route('books.destroy', $row->id)); ?>" method="post" id="deleteForm">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <a href="#" onclick="deleteConfirm(event)"><i class="fas fa-trash"></i></a>
                            </form>

                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
            <?php else: ?>


                    <p>No Book Found</p>

            <?php endif; ?>

        <?php echo e($books->links('layouts.pagination')); ?>

        <br><br>
    </div>

    <script>
        window.deleteConfirm = function (e) {
            e.preventDefault();
            var form = document.getElementById('deleteForm');

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebooklists\resources\views/books/index.blade.php ENDPATH**/ ?>